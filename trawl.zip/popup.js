// popup.js — Edge Explorer UI

// ── storage shim (mirrors background.js) ────────────────────────────────────
const store = (function () {
  const s = chrome.storage.session || chrome.storage.local;
  return {
    set:    (obj)  => new Promise(r => s.set(obj, r)),
    get:    (keys) => new Promise(r => s.get(keys, r)),
    remove: (keys) => new Promise(r => s.remove(keys, r))
  };
})();

// ── state ────────────────────────────────────────────────────────────────────
let crawlResult = null;
let pollTimer   = null;
let recsListenersAttached = false;

// ── utils ────────────────────────────────────────────────────────────────────
function $(id) { return document.getElementById(id); }

function showPanel(id) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  $(id).classList.add('active');
}

function showTabPanel(id) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  $(id).classList.add('active');
  document.querySelectorAll('.tab').forEach(t => {
    t.classList.toggle('active', t.dataset.panel === id);
  });
}

// ── tab switching ─────────────────────────────────────────────────────────────
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    showTabPanel(tab.dataset.panel);
    // Graph canvas dimensions are 0 when panel is hidden — re-render on tab switch
    if (tab.dataset.panel === 'graph-panel' && crawlResult) {
      renderGraph(crawlResult.graph, crawlResult.recommendations);
    }
  });
});

// ── start crawl ───────────────────────────────────────────────────────────────
$('start-btn').addEventListener('click', async () => {
  $('start-btn').disabled = true;

  // Get the active tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab || !tab.id) {
    alert('Cannot determine active tab.');
    $('start-btn').disabled = false;
    return;
  }

  // Block chrome:// and other non-injectable URLs
  const url = tab.url || '';
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    alert('Edge Explorer only works on http:// and https:// pages.');
    $('start-btn').disabled = false;
    return;
  }

  // Inject content script (executeScript is idempotent with guard in content.js)
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files:  ['src/content.js']
    });
  }
  catch (e) {
    alert('Could not inject into this page: ' + e.message);
    $('start-btn').disabled = false;
    return;
  }

  // Request link extraction from the injected content script
  let response;
  try {
    response = await new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_LINKS' }, res => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        resolve(res);
      });
    });
  }
  catch (e) {
    alert('Could not read page links: ' + e.message);
    $('start-btn').disabled = false;
    return;
  }

  if (!response || !response.links) {
    alert('No response from content script. Reload the page and try again.');
    $('start-btn').disabled = false;
    return;
  }

  showPanel('progress-panel');

  // Clear previous results
  await store.remove(['crawlResult', 'crawlProgress']);

  // Kick off the crawl in the background service worker
  chrome.runtime.sendMessage({
    type:      'START_CRAWL',
    rootUrl:   tab.url,
    rootLinks: response.links,
    rootText:  response.pageText
  });

  startPolling();
});

// ── polling ───────────────────────────────────────────────────────────────────
function startPolling() {
  if (pollTimer) clearInterval(pollTimer);

  pollTimer = setInterval(async () => {
    const data = await store.get(['crawlProgress', 'crawlResult']);
    const p = data.crawlProgress;
    if (!p) return;

    updateProgress(p);

    if (p.stage === 'done' && data.crawlResult) {
      clearInterval(pollTimer);
      pollTimer = null;
      crawlResult = data.crawlResult;
      renderResults();
    }
    if (p.stage === 'error') {
      clearInterval(pollTimer);
      pollTimer = null;
      alert('Crawl error: ' + (p.message || 'Unknown error'));
      showPanel('start-panel');
      $('start-btn').disabled = false;
    }
  }, 300);
}

function updateProgress(p) {
  const labels = { depth1: 'Crawling depth 1…', depth2: 'Crawling depth 2…', done: 'Done!' };
  $('prog-label').textContent = labels[p.stage] || p.stage;
  if (p.total > 0) {
    const pct = Math.round((p.done / p.total) * 100);
    $('prog-bar').style.width  = pct + '%';
    $('stat-pages').textContent = p.done;
    $('stat-depth').textContent = p.stage === 'depth2' ? 2 : 1;
  }
  if (p.url) $('prog-url').textContent = p.url;
}

// ── render results ────────────────────────────────────────────────────────────
function renderResults() {
  const { graph, recommendations } = crawlResult;
  const nodeCount = Object.keys(graph).length;
  const linkCount = Object.values(graph).reduce((a, n) => a + n.links.length, 0);

  $('stat-pages').textContent  = nodeCount;
  $('stat-links').textContent  = linkCount;
  $('stat-depth').textContent  = 2;
  $('depth-badge').textContent = nodeCount + ' nodes';

  $('tab-bar').style.display = 'flex';
  showTabPanel('recs-panel');

  renderRecs(recommendations);
  // Graph rendered on tab-switch to ensure canvas has dimensions
  renderData(graph, recommendations);
}

// ── recommendations ───────────────────────────────────────────────────────────
let allRecs = [];

function renderRecs(recs) {
  allRecs = recs;
  buildRecList(recs);

  // Attach listeners only once
  if (!recsListenersAttached) {
    recsListenersAttached = true;
    $('rec-search').addEventListener('input',  filterRecs);
    $('rec-sort').addEventListener('change', filterRecs);
  }
}

function filterRecs() {
  const q    = $('rec-search').value.toLowerCase();
  const sort = $('rec-sort').value;

  let filtered = allRecs.filter(r =>
    (r.title || '').toLowerCase().includes(q) ||
    (r.url   || '').toLowerCase().includes(q)
  );

  if (sort === 'freq')  filtered.sort((a, b) => (b.freq        || 0) - (a.freq        || 0));
  if (sort === 'sim')   filtered.sort((a, b) => (b.similarity  || 0) - (a.similarity  || 0));
  if (sort === 'depth') filtered.sort((a, b) => (a.depth       || 0) - (b.depth       || 0));

  buildRecList(filtered);
}

function buildRecList(recs) {
  const list = $('recs-list');
  if (!recs.length) {
    list.innerHTML = '<div class="empty">No matches</div>';
    return;
  }

  list.innerHTML = recs.map((r, i) => {
    const sc      = r.score || 0;
    const scoreCls = sc >= 60 ? 'score-high' : sc >= 30 ? 'score-mid' : 'score-low';
    const depthCls = r.depth === 1 ? 'pill-d1' : r.depth === 2 ? 'pill-d2' : 'pill-d0';
    const freq     = r.freq  || 0;
    const sim      = Math.round((r.similarity || 0) * 100);
    const title    = esc(r.title || r.url);
    const urlDisp  = esc((r.url || '').replace(/^https?:\/\//, '').slice(0, 60));
    const encodedUrl = encodeURIComponent(r.url || '');

    return '<div class="rec-card" data-idx="' + i + '">' +
      '<div class="rec-score ' + scoreCls + '">' + sc + '</div>' +
      '<div class="rec-body">' +
        '<div class="rec-title" title="' + title + '">' + title + '</div>' +
        '<div class="rec-url">' + urlDisp + '</div>' +
        '<div class="rec-pills">' +
          '<span class="pill ' + depthCls + '">Depth ' + r.depth + '</span>' +
          (freq ? '<span class="pill pill-freq">↗ ' + freq + ' links</span>' : '') +
          (sim  ? '<span class="pill pill-sim">~' + sim + '% match</span>'  : '') +
        '</div>' +
      '</div>' +
      '<button class="open-btn" data-url="' + encodedUrl + '">Open ↗</button>' +
    '</div>';
  }).join('');

  list.querySelectorAll('.open-btn').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const target = decodeURIComponent(btn.getAttribute('data-url'));
      chrome.tabs.create({ url: target });
    });
  });
}

function esc(str) {
  return (str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ── graph (force-directed canvas) ────────────────────────────────────────────
let graphRendered = false;

function renderGraph(graph, recs) {
  const canvas = $('graph-canvas');
  const panel  = $('graph-panel');

  // Use actual DOM dimensions — only valid if panel is visible
  const w = panel.clientWidth  || 560;
  const h = panel.clientHeight || 450;
  canvas.width  = w;
  canvas.height = h;

  const ctx = canvas.getContext('2d');

  const scoreMap = {};
  recs.forEach(r => { scoreMap[r.norm || r.url] = r.score || 0; });

  const nodeEntries = Object.entries(graph);
  const nodes = nodeEntries.map(function(entry) {
    const norm = entry[0], n = entry[1];
    return {
      id:    norm,
      url:   n.url,
      title: n.title,
      depth: n.depth || 0,
      score: scoreMap[norm] || 0,
      freq:  n.freq  || 0,
      x:  w / 2 + (Math.random() - 0.5) * 180,
      y:  h / 2 + (Math.random() - 0.5) * 180,
      vx: 0, vy: 0, r: 0
    };
  });

  const nodeMap = {};
  nodes.forEach(n => { nodeMap[n.id] = n; });

  const edges = [];
  nodeEntries.forEach(function(entry) {
    const srcNorm = entry[0], n = entry[1];
    if (!nodeMap[srcNorm]) return;
    (n.links || []).forEach(tgt => {
      if (nodeMap[tgt]) edges.push({ src: nodeMap[srcNorm], tgt: nodeMap[tgt] });
    });
  });

  nodes.forEach(n => {
    n.r = n.depth === 0 ? 10 : n.score >= 60 ? 7 : n.score >= 30 ? 5 : 4;
  });

  function nodeColor(n) {
    if (n.depth === 0)   return '#5b8af0';
    if (n.score >= 60)   return '#f5a623';
    if (n.depth === 1)   return '#3ecf8e';
    return '#58668c';
  }

  let zoom = 1, panX = 0, panY = 0;
  let simStep = 0;
  const MAX_STEPS = 280;
  let animId = null;

  function simulate() {
    if (simStep >= MAX_STEPS) { draw(); return; }
    simStep++;

    const nodeCount = nodes.length || 1;
    const k    = Math.sqrt((w * h) / nodeCount);
    const cool = 1 - simStep / MAX_STEPS;

    for (let i = 0; i < nodes.length; i++) {
      nodes[i].vx = 0; nodes[i].vy = 0;
      for (let j = 0; j < nodes.length; j++) {
        if (i === j) continue;
        const dx = nodes[i].x - nodes[j].x;
        const dy = nodes[i].y - nodes[j].y;
        const d2 = dx * dx + dy * dy + 0.01;
        const f  = (k * k) / d2;
        nodes[i].vx += dx * f;
        nodes[i].vy += dy * f;
      }
    }

    edges.forEach(function(e) {
      const dx = e.tgt.x - e.src.x;
      const dy = e.tgt.y - e.src.y;
      const d  = Math.sqrt(dx * dx + dy * dy) + 0.01;
      const f  = (d * d / k) * 0.5;
      e.src.vx += (dx / d) * f; e.src.vy += (dy / d) * f;
      e.tgt.vx -= (dx / d) * f; e.tgt.vy -= (dy / d) * f;
    });

    nodes.forEach(n => {
      n.vx += (w / 2 - n.x) * 0.005;
      n.vy += (h / 2 - n.y) * 0.005;
      const d    = Math.sqrt(n.vx * n.vx + n.vy * n.vy) + 0.01;
      const temp = 30 * cool;
      n.x += (n.vx / d) * Math.min(d, temp);
      n.y += (n.vy / d) * Math.min(d, temp);
      n.x = Math.max(n.r + 2, Math.min(w - n.r - 2, n.x));
      n.y = Math.max(n.r + 2, Math.min(h - n.r - 2, n.y));
    });

    draw();
    animId = requestAnimationFrame(simulate);
  }

  function draw() {
    ctx.clearRect(0, 0, w, h);
    ctx.save();
    ctx.translate(panX, panY);
    ctx.scale(zoom, zoom);

    ctx.globalAlpha = 0.2;
    ctx.strokeStyle = '#5b8af0';
    ctx.lineWidth   = 0.5;
    edges.forEach(function(e) {
      ctx.beginPath();
      ctx.moveTo(e.src.x, e.src.y);
      ctx.lineTo(e.tgt.x, e.tgt.y);
      ctx.stroke();
    });
    ctx.globalAlpha = 1;

    nodes.forEach(n => {
      ctx.beginPath();
      ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
      ctx.fillStyle = nodeColor(n);
      ctx.fill();
      if (n.depth === 0) {
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth   = 1.5;
        ctx.stroke();
      }
    });

    ctx.restore();
  }

  // Cancel any previous animation loop before starting a new one
  if (animId) cancelAnimationFrame(animId);
  simStep = 0;
  simulate();

  // ── interaction ───────────────────────────────────────────────────────────
  // Remove old listeners by cloning canvas (cleanest approach for re-render)
  const fresh = canvas.cloneNode(true);
  canvas.parentNode.replaceChild(fresh, canvas);
  const c = fresh;
  const cx2 = c.getContext('2d');
  // point draw/simulate at new context
  // (they close over ctx — reassign)
  Object.defineProperty(c, '__ctx', { value: cx2 });

  let dragging = false, lastMx = 0, lastMy = 0;

  c.addEventListener('mousedown', e => {
    dragging = true; lastMx = e.clientX; lastMy = e.clientY;
  });

  c.addEventListener('mousemove', e => {
    if (dragging) {
      panX += e.clientX - lastMx;
      panY += e.clientY - lastMy;
      lastMx = e.clientX; lastMy = e.clientY;
      draw();
    }
    const rect = c.getBoundingClientRect();
    const mx = (e.clientX - rect.left - panX) / zoom;
    const my = (e.clientY - rect.top  - panY) / zoom;
    const hover = nodes.find(n => {
      const dx = n.x - mx, dy = n.y - my;
      return Math.sqrt(dx * dx + dy * dy) < n.r + 4;
    });
    const tt = $('node-tooltip');
    if (hover) {
      $('tt-title').textContent = hover.title || hover.url;
      $('tt-url').textContent   = hover.url;
      $('tt-score').textContent = hover.depth === 0 ? 'Root page' : 'Score: ' + hover.score;
      tt.style.display = 'block';
      tt.style.left    = (e.clientX - rect.left + 14) + 'px';
      tt.style.top     = (e.clientY - rect.top  +  4) + 'px';
    } else {
      tt.style.display = 'none';
    }
  });

  c.addEventListener('mouseup',    () => { dragging = false; });
  c.addEventListener('mouseleave', () => { dragging = false; $('node-tooltip').style.display = 'none'; });

  c.addEventListener('wheel', e => {
    e.preventDefault();
    zoom = Math.max(0.2, Math.min(4, zoom * (e.deltaY < 0 ? 1.1 : 0.9)));
    draw();
  }, { passive: false });

  $('zoom-in').onclick  = () => { zoom = Math.min(4,   zoom * 1.3); draw(); };
  $('zoom-out').onclick = () => { zoom = Math.max(0.2, zoom / 1.3); draw(); };
  $('zoom-fit').onclick = () => { zoom = 1; panX = 0; panY = 0; draw(); };
}

// ── raw data ──────────────────────────────────────────────────────────────────
function renderData(graph, recommendations) {
  const payload = {
    crawledAt:   new Date().toISOString(),
    totalNodes:  Object.keys(graph).length,
    totalEdges:  Object.values(graph).reduce((a, n) => a + (n.links || []).length, 0),
    recommendations: recommendations.map(r => ({
      url:        r.url,
      title:      r.title,
      score:      r.score,
      depth:      r.depth,
      freq:       r.freq,
      similarity: Math.round((r.similarity || 0) * 100)
    })),
    graph: Object.fromEntries(
      Object.entries(graph).map(function(entry) {
        const k = entry[0], v = entry[1];
        return [k, {
          url:      v.url,
          title:    v.title,
          depth:    v.depth,
          outLinks: (v.links || []).length,
          freq:     v.freq
        }];
      })
    )
  };

  const jsonStr = JSON.stringify(payload, null, 2);
  $('data-inner').textContent = jsonStr;

  // Use the clipboard API with the clipboardWrite permission
  $('copy-json').onclick = function() {
    navigator.clipboard.writeText(jsonStr).then(() => {
      const btn = $('copy-json');
      btn.textContent = 'Copied!';
      setTimeout(() => { btn.textContent = 'Copy JSON'; }, 1500);
    });
  };

  $('copy-csv').onclick = function() {
    const rows = ['URL,Title,Score,Depth,Freq,Similarity%'];
    recommendations.forEach(r => {
      rows.push([
        '"' + (r.url   || '') + '"',
        '"' + (r.title || '').replace(/"/g, '""') + '"',
        r.score,
        r.depth,
        r.freq,
        Math.round((r.similarity || 0) * 100)
      ].join(','));
    });
    navigator.clipboard.writeText(rows.join('\n')).then(() => {
      const btn = $('copy-csv');
      btn.textContent = 'Copied!';
      setTimeout(() => { btn.textContent = 'Copy CSV'; }, 1500);
    });
  };

  $('dl-json').onclick = function() {
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const a    = document.createElement('a');
    a.href     = URL.createObjectURL(blob);
    a.download = 'edge-explorer.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(a.href);
  };
}
