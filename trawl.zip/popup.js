// popup.js

// ── state ────────────────────────────────────────────────────────────────────
let crawlResult = null;
let pollTimer   = null;

// ── utils ────────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);

function showPanel(id) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  $(id).classList.add('active');
}

function showTabPanel(id) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  $(id).classList.add('active');
  document.querySelectorAll('.tab').forEach(t => {
    t.classList.toggle('active', t.dataset.panel === id);
  });
}

// ── tab switching ─────────────────────────────────────────────────────────────
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => showTabPanel(tab.dataset.panel));
});

// ── start crawl ───────────────────────────────────────────────────────────────
$('start-btn').addEventListener('click', async () => {
  $('start-btn').disabled = true;

  // get active tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  // inject content script if needed and extract links
  let response;
  try {
    [response] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['src/content.js']
    }).catch(() => []);

    response = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_LINKS' });
  } catch (e) {
    alert('Cannot access this page. Try a regular http/https page.');
    $('start-btn').disabled = false;
    return;
  }

  showPanel('progress-panel');

  // clear previous result
  await chrome.storage.session.remove(['crawlResult', 'crawlProgress']);

  // kick off background crawl
  chrome.runtime.sendMessage({
    type:      'START_CRAWL',
    rootUrl:   tab.url,
    rootLinks: response.links,
    rootText:  response.pageText
  });

  // start polling progress
  startPolling();
});

// ── polling ───────────────────────────────────────────────────────────────────
function startPolling() {
  pollTimer = setInterval(async () => {
    const { crawlProgress, crawlResult: result } =
      await chrome.storage.session.get(['crawlProgress', 'crawlResult']);

    if (!crawlProgress) return;

    updateProgress(crawlProgress);

    if (crawlProgress.stage === 'done' && result) {
      clearInterval(pollTimer);
      crawlResult = result;
      renderResults();
    }
    if (crawlProgress.stage === 'error') {
      clearInterval(pollTimer);
      alert('Crawl error: ' + crawlProgress.message);
      showPanel('start-panel');
      $('start-btn').disabled = false;
    }
  }, 300);
}

function updateProgress(p) {
  const stageLabel = { depth1: 'Crawling depth 1', depth2: 'Crawling depth 2', done: 'Done!' };
  $('prog-label').textContent = stageLabel[p.stage] || p.stage;
  if (p.total > 0) {
    $('prog-bar').style.width = Math.round((p.done / p.total) * 100) + '%';
    $('stat-pages').textContent = p.done;
    $('stat-depth').textContent = p.stage === 'depth2' ? 2 : 1;
  }
  if (p.url) $('prog-url').textContent = p.url;
}

// ── render results ────────────────────────────────────────────────────────────
function renderResults() {
  const { graph, recommendations } = crawlResult;
  const nodeCount = Object.keys(graph).length;
  const linkCount = Object.values(graph).reduce((a, n) => a + n.links.length, 0);

  $('stat-pages').textContent = nodeCount;
  $('stat-links').textContent = linkCount;
  $('stat-depth').textContent = 2;
  $('depth-badge').textContent = `${nodeCount} nodes`;

  $('tab-bar').style.display = 'flex';
  showTabPanel('recs-panel');

  renderRecs(recommendations);
  renderGraph(graph, recommendations);
  renderData(graph, recommendations);
}

// ── recommendations ───────────────────────────────────────────────────────────
let allRecs = [];

function renderRecs(recs) {
  allRecs = recs;
  buildRecList(recs);

  $('rec-search').addEventListener('input', filterRecs);
  $('rec-sort').addEventListener('change', filterRecs);
}

function filterRecs() {
  const q    = $('rec-search').value.toLowerCase();
  const sort = $('rec-sort').value;

  let filtered = allRecs.filter(r =>
    r.title.toLowerCase().includes(q) || r.url.toLowerCase().includes(q)
  );

  if (sort === 'freq')  filtered.sort((a, b) => (b.freq  || 0) - (a.freq  || 0));
  if (sort === 'sim')   filtered.sort((a, b) => (b.similarity || 0) - (a.similarity || 0));
  if (sort === 'depth') filtered.sort((a, b) => (a.depth || 0) - (b.depth || 0));
  // default: score already sorted

  buildRecList(filtered);
}

function buildRecList(recs) {
  const list = $('recs-list');
  if (!recs.length) { list.innerHTML = '<div class="empty">No matches</div>'; return; }

  list.innerHTML = recs.map((r, i) => {
    const sc    = r.score || 0;
    const cls   = sc >= 60 ? 'score-high' : sc >= 30 ? 'score-mid' : 'score-low';
    const dCls  = r.depth === 0 ? 'pill-d0' : r.depth === 1 ? 'pill-d1' : 'pill-d2';
    const freq  = r.freq  || 0;
    const sim   = Math.round((r.similarity || 0) * 100);
    const title = r.title || r.url;
    const urlDisp = r.url.replace(/^https?:\/\//, '').slice(0, 60);

    return `
      <div class="rec-card" data-url="${encodeURIComponent(r.url)}" data-idx="${i}">
        <div class="rec-score ${cls}">${sc}</div>
        <div class="rec-body">
          <div class="rec-title" title="${esc(title)}">${esc(title)}</div>
          <div class="rec-url">${esc(urlDisp)}</div>
          <div class="rec-pills">
            <span class="pill ${dCls}">Depth ${r.depth}</span>
            ${freq  ? `<span class="pill pill-freq">↗ ${freq} links</span>` : ''}
            ${sim   ? `<span class="pill pill-sim">~${sim}% match</span>` : ''}
          </div>
        </div>
        <button class="open-btn" data-url="${encodeURIComponent(r.url)}">Open ↗</button>
      </div>`;
  }).join('');

  list.querySelectorAll('.open-btn').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      chrome.tabs.create({ url: decodeURIComponent(btn.dataset.url) });
    });
  });
}

function esc(str) {
  return (str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ── graph renderer (canvas force-directed) ────────────────────────────────────
function renderGraph(graph, recs) {
  const canvas = $('graph-canvas');
  const parent = document.getElementById('graph-panel');
  canvas.width  = parent.clientWidth  || 560;
  canvas.height = parent.clientHeight || 450;
  const ctx = canvas.getContext('2d');

  const scoreMap = {};
  recs.forEach(r => { scoreMap[r.norm || r.url] = r.score || 0; });

  // build nodes + edges
  const nodes = Object.entries(graph).map(([norm, n], i) => ({
    id: norm, url: n.url, title: n.title, depth: n.depth || 0,
    score: scoreMap[norm] || 0, freq: n.freq || 0,
    x: canvas.width  / 2 + (Math.random() - 0.5) * 200,
    y: canvas.height / 2 + (Math.random() - 0.5) * 200,
    vx: 0, vy: 0, r: 0
  }));

  const nodeMap = {};
  nodes.forEach(n => nodeMap[n.id] = n);

  const edges = [];
  Object.entries(graph).forEach(([srcNorm, n]) => {
    n.links.forEach(tgt => {
      if (nodeMap[tgt] && nodeMap[srcNorm]) edges.push({ src: nodeMap[srcNorm], tgt: nodeMap[tgt] });
    });
  });

  // node radius
  nodes.forEach(n => {
    n.r = n.depth === 0 ? 10 : n.score >= 60 ? 7 : n.score >= 30 ? 5 : 4;
  });

  // colour
  function nodeColor(n) {
    if (n.depth === 0) return '#5b8af0';
    if (n.score >= 60) return '#f5a623';
    if (n.depth === 1) return '#3ecf8e';
    return '#58668c';
  }

  // force simulation
  let zoom = 1, panX = 0, panY = 0;
  let simSteps = 0;
  const MAX_SIM = 300;

  function simulate() {
    if (simSteps++ > MAX_SIM) return;
    const k  = Math.sqrt((canvas.width * canvas.height) / nodes.length);
    const cool = 1 - simSteps / MAX_SIM;

    // repulsion
    for (let i = 0; i < nodes.length; i++) {
      nodes[i].vx = 0; nodes[i].vy = 0;
      for (let j = 0; j < nodes.length; j++) {
        if (i === j) continue;
        const dx = nodes[i].x - nodes[j].x;
        const dy = nodes[i].y - nodes[j].y;
        const d2 = dx * dx + dy * dy + 0.01;
        const f  = (k * k) / d2;
        nodes[i].vx += dx * f;
        nodes[i].vy += dy * f;
      }
    }
    // attraction
    edges.forEach(({ src, tgt }) => {
      const dx = tgt.x - src.x, dy = tgt.y - src.y;
      const d  = Math.sqrt(dx * dx + dy * dy) + 0.01;
      const f  = (d * d / k) * 0.5;
      src.vx += dx * f / d; src.vy += dy * f / d;
      tgt.vx -= dx * f / d; tgt.vy -= dy * f / d;
    });
    // gravity to centre
    nodes.forEach(n => {
      n.vx += (canvas.width / 2  - n.x) * 0.005;
      n.vy += (canvas.height / 2 - n.y) * 0.005;
    });
    // apply
    const temp = 30 * cool;
    nodes.forEach(n => {
      const d = Math.sqrt(n.vx * n.vx + n.vy * n.vy) + 0.01;
      n.x += (n.vx / d) * Math.min(d, temp);
      n.y += (n.vy / d) * Math.min(d, temp);
      n.x = Math.max(n.r + 2, Math.min(canvas.width  - n.r - 2, n.x));
      n.y = Math.max(n.r + 2, Math.min(canvas.height - n.r - 2, n.y));
    });
    draw();
    requestAnimationFrame(simulate);
  }

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.translate(panX, panY);
    ctx.scale(zoom, zoom);

    // edges
    ctx.globalAlpha = 0.25;
    edges.forEach(({ src, tgt }) => {
      ctx.beginPath();
      ctx.moveTo(src.x, src.y);
      ctx.lineTo(tgt.x, tgt.y);
      ctx.strokeStyle = '#5b8af0';
      ctx.lineWidth   = 0.5;
      ctx.stroke();
    });
    ctx.globalAlpha = 1;

    // nodes
    nodes.forEach(n => {
      ctx.beginPath();
      ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
      ctx.fillStyle = nodeColor(n);
      ctx.fill();
      if (n.depth === 0) {
        ctx.strokeStyle = '#fff';
        ctx.lineWidth   = 1.5;
        ctx.stroke();
      }
    });

    ctx.restore();
  }

  simulate();

  // ── pan / zoom ──
  let dragging = false, lastMx = 0, lastMy = 0;

  canvas.addEventListener('mousedown', e => {
    dragging = true; lastMx = e.clientX; lastMy = e.clientY;
  });
  canvas.addEventListener('mousemove', e => {
    if (dragging) {
      panX += e.clientX - lastMx; panY += e.clientY - lastMy;
      lastMx = e.clientX; lastMy = e.clientY;
      draw();
    }
    // tooltip
    const rect  = canvas.getBoundingClientRect();
    const mx    = (e.clientX - rect.left - panX) / zoom;
    const my    = (e.clientY - rect.top  - panY) / zoom;
    const hover = nodes.find(n => Math.hypot(n.x - mx, n.y - my) < n.r + 4);
    const tt    = $('node-tooltip');
    if (hover) {
      $('tt-title').textContent = hover.title || hover.url;
      $('tt-url').textContent   = hover.url;
      $('tt-score').textContent = hover.depth === 0 ? 'Root page' : `Score: ${hover.score}`;
      tt.style.display   = 'block';
      tt.style.left      = (e.clientX - rect.left + 12) + 'px';
      tt.style.top       = (e.clientY - rect.top  + 4 ) + 'px';
    } else { tt.style.display = 'none'; }
  });
  canvas.addEventListener('mouseup',    () => dragging = false);
  canvas.addEventListener('mouseleave', () => { dragging = false; $('node-tooltip').style.display = 'none'; });

  canvas.addEventListener('wheel', e => {
    e.preventDefault();
    zoom = Math.max(0.2, Math.min(4, zoom * (e.deltaY < 0 ? 1.1 : 0.9)));
    draw();
  }, { passive: false });

  $('zoom-in').addEventListener('click',  () => { zoom = Math.min(4, zoom * 1.3); draw(); });
  $('zoom-out').addEventListener('click', () => { zoom = Math.max(0.2, zoom / 1.3); draw(); });
  $('zoom-fit').addEventListener('click', () => { zoom = 1; panX = 0; panY = 0; draw(); });
}

// ── raw data ──────────────────────────────────────────────────────────────────
function renderData(graph, recommendations) {
  const payload = {
    crawledAt:       new Date().toISOString(),
    totalNodes:      Object.keys(graph).length,
    totalEdges:      Object.values(graph).reduce((a, n) => a + n.links.length, 0),
    recommendations: recommendations.map(r => ({
      url: r.url, title: r.title, score: r.score,
      depth: r.depth, freq: r.freq,
      similarity: Math.round((r.similarity || 0) * 100)
    })),
    graph: Object.fromEntries(
      Object.entries(graph).map(([k, v]) => [k, {
        url: v.url, title: v.title, depth: v.depth,
        outLinks: v.links.length, freq: v.freq
      }])
    )
  };

  $('data-inner').textContent = JSON.stringify(payload, null, 2);

  $('copy-json').addEventListener('click', () => {
    navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
    $('copy-json').textContent = 'Copied!';
    setTimeout(() => { $('copy-json').textContent = 'Copy JSON'; }, 1500);
  });

  $('copy-csv').addEventListener('click', () => {
    const rows = ['URL,Title,Score,Depth,Freq,Similarity%'];
    recommendations.forEach(r => {
      rows.push([
        `"${r.url}"`, `"${(r.title||'').replace(/"/g,'""')}"`,
        r.score, r.depth, r.freq,
        Math.round((r.similarity||0)*100)
      ].join(','));
    });
    navigator.clipboard.writeText(rows.join('\n'));
    $('copy-csv').textContent = 'Copied!';
    setTimeout(() => { $('copy-csv').textContent = 'Copy CSV'; }, 1500);
  });

  $('dl-json').addEventListener('click', () => {
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const a    = document.createElement('a');
    a.href     = URL.createObjectURL(blob);
    a.download = 'edge-explorer.json';
    a.click();
  });
}
