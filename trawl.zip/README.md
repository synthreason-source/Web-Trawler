# Edge Explorer — Chrome Extension

A zero-dependency link graph crawler and AI-free recommender that runs entirely inside your browser.

## What it does

1. **Depth 0** — extracts every `<a href>` on the current tab via a content script
2. **Depth 1** — fetches each same-domain internal link (up to 30), extracts their links
3. **Depth 2** — fetches secondary pages (up to 40), extracts links
4. **Builds a graph** — page → embedded links, with inbound-anchor tracking
5. **Scores & recommends** using three signals:
   - **Link frequency** — how many crawled pages point to the candidate (40 % weight)
   - **TF-IDF content similarity** — cosine similarity of the candidate's text vs the root page (40 % weight)
   - **Anchor text presence** — whether the link appears with descriptive anchor text (20 % weight)

All processing happens in the background service worker. No external API calls.

---

## Install (Developer / Unpacked)

1. Open Chrome and go to `chrome://extensions`
2. Enable **Developer mode** (top-right toggle)
3. Click **Load unpacked**
4. Select this folder (`edge-explorer/`)
5. The "EE" icon appears in your toolbar

> **Note:** The extension requests `host_permissions: <all_urls>` so it can fetch cross-origin pages during the crawl. It never sends data anywhere.

---

## Usage

1. Navigate to any `http://` or `https://` page
2. Click the **Edge Explorer** toolbar icon
3. Click **Start crawl** — the progress screen shows live depth / page counts
4. When done, three tabs appear:

| Tab | What you get |
|-----|-------------|
| **Recommendations** | Ranked list with score, depth badge, frequency and similarity pills. Filter by text or sort by signal. Click **Open ↗** to visit. |
| **Graph** | Force-directed canvas graph. Drag to pan, scroll to zoom, hover nodes for details. Gold = high-score, green = depth 1, grey = depth 2, blue = root. |
| **Raw Data** | Full JSON/CSV export of the crawl. Copy to clipboard or download. |

---

## Scoring formula

```
score = (anchor_score × 0.2) + (freq_score × 0.4) + (tfidf_sim × 0.4)
```

- `anchor_score` — 1 if the URL appears with any anchor text across the crawl, else 0
- `freq_score`   — `min(inbound_link_count / 5, 1.0)`
- `tfidf_sim`    — cosine similarity (0–1) between the candidate page and the root

---

## Adding PageRank / Moz

To add external authority signals, edit `src/background.js`:

```js
// In the processD1 / processD2 functions, after fetching HTML:
const mozData = await fetch(
  `https://lsapi.seomoz.com/v2/url_metrics`,
  { method: 'POST', headers: { Authorization: 'Basic ' + btoa('YOUR_KEY') },
    body: JSON.stringify({ targets: [link.href] }) }
).then(r => r.json());

node.domainAuthority = mozData?.results?.[0]?.domain_authority || 0;
```

Then adjust the scoring weights in the `scored` map at the bottom of `crawl()`.

---

## Files

```
edge-explorer/
├── manifest.json        Chrome Manifest V3
├── popup.html           Extension popup UI
├── popup.js             UI logic — tabs, recs list, graph renderer, data export
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── src/
    ├── content.js       Injected into pages — extracts links + text
    └── background.js    Service worker — crawl orchestration, TF-IDF, scoring
```

---

## Limitations

- **CORS**: some pages block cross-origin fetches. Those pages return `null` and are skipped (their depth-0 links still appear in the graph from the root page's extraction).
- **JS-rendered pages**: depth-1/2 fetches are raw HTML — single-page apps with client-side routing won't expose their links. The root page always uses the live DOM via the content script.
- **Popup stays open**: the crawl runs in the background service worker, but Chrome may kill the popup if you close it before it finishes. The result is persisted in `chrome.storage.session` and will reappear if you re-open the popup.

---

## Privacy

- No data leaves your browser
- No analytics, no telemetry
- All fetches go directly from your browser to the target domain
