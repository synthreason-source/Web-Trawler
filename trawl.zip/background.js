// background.js — service worker
// Manages the crawl queue, fetches pages, builds the graph.

const CONCURRENCY = 4;
const FETCH_TIMEOUT_MS = 8000;

// ── helpers ──────────────────────────────────────────────────────────────────

function sameDomain(a, b) {
  try { return new URL(a).hostname === new URL(b).hostname; } catch { return false; }
}

function normUrl(href, base) {
  try {
    const u = new URL(href, base);
    if (!['http:', 'https:'].includes(u.protocol)) return null;
    return u.origin + u.pathname.replace(/\/$/, '') + u.search;
  } catch { return null; }
}

// Extract <a href> links from raw HTML text (used for depth-1/2 fetches)
function extractLinksFromHtml(html, baseUrl) {
  const links = [];
  const seen  = new Set();
  // lightweight regex — avoids DOM overhead in service worker
  const re = /<a[^>]+href=["']([^"'#][^"']*)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(html)) !== null) {
    const norm = normUrl(m[1], baseUrl);
    if (!norm || seen.has(norm)) continue;
    seen.add(norm);
    const anchor = m[2].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim().slice(0, 120);
    links.push({ href: norm, norm, anchor, sameDomain: sameDomain(norm, baseUrl) });
  }
  return links;
}

// Extract plain text from HTML (for TF-IDF)
function htmlToText(html) {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 3000);
}

async function fetchPage(url) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      credentials: 'omit',
      headers: { 'Accept': 'text/html' }
    });
    clearTimeout(t);
    if (!res.ok) return null;
    const ct = res.headers.get('content-type') || '';
    if (!ct.includes('text/html')) return null;
    return await res.text();
  } catch {
    clearTimeout(t);
    return null;
  }
}

// ── TF-IDF similarity ─────────────────────────────────────────────────────────

function tokenise(text) {
  return text.toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(w => w.length > 2);
}

function tfIdf(corpus) {
  // corpus: [{url, text}]
  const tfs  = corpus.map(d => {
    const tokens = tokenise(d.text);
    const freq   = {};
    tokens.forEach(t => freq[t] = (freq[t] || 0) + 1);
    const max = Math.max(...Object.values(freq), 1);
    Object.keys(freq).forEach(t => freq[t] /= max);
    return freq;
  });
  const df = {};
  tfs.forEach(tf => Object.keys(tf).forEach(t => df[t] = (df[t] || 0) + 1));
  const N = corpus.length;
  return tfs.map(tf => {
    const tfidf = {};
    Object.entries(tf).forEach(([t, v]) => {
      tfidf[t] = v * Math.log((N + 1) / (df[t] + 1));
    });
    return tfidf;
  });
}

function cosineSim(a, b) {
  const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
  let dot = 0, na = 0, nb = 0;
  keys.forEach(k => {
    const av = a[k] || 0, bv = b[k] || 0;
    dot += av * bv; na += av * av; nb += bv * bv;
  });
  if (!na || !nb) return 0;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}

// ── main crawl logic ──────────────────────────────────────────────────────────

async function crawl(rootUrl, rootLinks, rootText, sendProgress) {
  // rootLinks: [{href,norm,anchor,sameDomain}] from content script
  const graph   = {}; // norm → {url, title, links:[norm], text, inboundAnchors:[str], freq:0}
  const visited = new Set();

  const internalLinks = rootLinks.filter(l => l.sameDomain);

  // depth-0 node
  graph[rootUrl] = {
    url: rootUrl, title: 'Current page',
    links: internalLinks.map(l => l.norm),
    text: rootText, inboundAnchors: [], freq: 0, depth: 0
  };
  visited.add(rootUrl);

  // ── depth 1 ──
  sendProgress({ stage: 'depth1', total: internalLinks.length, done: 0 });

  const depth1Queue = internalLinks.slice(0, 30); // cap at 30
  let d1done = 0;

  async function processD1(link) {
    const html = await fetchPage(link.href);
    d1done++;
    sendProgress({ stage: 'depth1', total: depth1Queue.length, done: d1done, url: link.href });
    if (!html) return;

    const subLinks = extractLinksFromHtml(html, link.href).filter(l => l.sameDomain);
    graph[link.norm] = {
      url: link.href, title: link.anchor || link.href,
      links: subLinks.map(l => l.norm),
      text: htmlToText(html),
      inboundAnchors: [link.anchor],
      freq: 0, depth: 1
    };
    visited.add(link.norm);

    // track inbound anchors on root's neighbours
    subLinks.forEach(sl => {
      if (!graph[sl.norm]) graph[sl.norm] = { url: sl.href, title: sl.anchor || sl.href, links: [], text: '', inboundAnchors: [], freq: 0, depth: 2 };
      graph[sl.norm].inboundAnchors.push(sl.anchor);
    });
  }

  // run with concurrency limit
  for (let i = 0; i < depth1Queue.length; i += CONCURRENCY) {
    await Promise.all(depth1Queue.slice(i, i + CONCURRENCY).map(processD1));
  }

  // ── depth 2 ──
  const depth2Urls = Object.values(graph)
    .filter(n => n.depth === 2 && !visited.has(n.url))
    .slice(0, 40);

  sendProgress({ stage: 'depth2', total: depth2Urls.length, done: 0 });
  let d2done = 0;

  async function processD2(node) {
    const html = await fetchPage(node.url);
    d2done++;
    sendProgress({ stage: 'depth2', total: depth2Urls.length, done: d2done, url: node.url });
    if (!html) return;
    node.text  = htmlToText(html);
    node.links = extractLinksFromHtml(html, node.url).filter(l => l.sameDomain).map(l => l.norm);
    visited.add(node.url);
  }

  for (let i = 0; i < depth2Urls.length; i += CONCURRENCY) {
    await Promise.all(depth2Urls.slice(i, i + CONCURRENCY).map(processD2));
  }

  // ── frequency count ──
  // how many pages link to each node
  Object.values(graph).forEach(node => {
    node.links.forEach(targetNorm => {
      if (graph[targetNorm]) graph[targetNorm].freq++;
    });
  });

  // ── TF-IDF similarity ──
  const corpus = Object.values(graph).filter(n => n.text);
  const vectors = tfIdf(corpus);
  const rootVec = vectors[0] || {};
  corpus.forEach((node, i) => {
    node.similarity = i === 0 ? 1 : cosineSim(rootVec, vectors[i]);
  });

  // ── score & recommend ──
  const scored = Object.values(graph)
    .filter(n => n.url !== rootUrl)
    .map(n => {
      const anchorScore = n.inboundAnchors.filter(Boolean).length > 0 ? 1 : 0;
      const freqScore   = Math.min(n.freq / 5, 1);
      const simScore    = n.similarity || 0;
      const score       = (anchorScore * 0.2) + (freqScore * 0.4) + (simScore * 0.4);
      return { ...n, score: Math.round(score * 100) };
    })
    .sort((a, b) => b.score - a.score);

  return { graph, recommendations: scored.slice(0, 20) };
}

// ── message handler ───────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type !== 'START_CRAWL') return;

  const { rootUrl, rootLinks, rootText } = msg;

  // Use a port-like pattern: send incremental updates via storage,
  // final result via sendResponse
  (async () => {
    function sendProgress(p) {
      chrome.storage.session.set({ crawlProgress: p });
    }

    try {
      const result = await crawl(rootUrl, rootLinks, rootText, sendProgress);
      chrome.storage.session.set({ crawlResult: result, crawlProgress: { stage: 'done' } });
      sendResponse({ ok: true });
    } catch (e) {
      chrome.storage.session.set({ crawlProgress: { stage: 'error', message: e.message } });
      sendResponse({ ok: false, error: e.message });
    }
  })();

  return true; // keep channel open
});
