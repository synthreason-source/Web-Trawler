// content.js — runs in page context, extracts links on demand

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === 'EXTRACT_LINKS') {
    const base = new URL(location.href);
    const links = [];
    const seen = new Set();

    document.querySelectorAll('a[href]').forEach(a => {
      try {
        const url = new URL(a.getAttribute('href'), base);
        // normalise: strip hash, trailing slash
        const norm = url.origin + url.pathname.replace(/\/$/, '') + url.search;
        if (seen.has(norm)) return;
        seen.add(norm);
        links.push({
          href: url.href,
          norm,
          anchor: (a.textContent || a.getAttribute('aria-label') || '').trim().slice(0, 120),
          sameDomain: url.hostname === base.hostname,
          x: a.getBoundingClientRect().left,
          y: a.getBoundingClientRect().top
        });
      } catch (_) {}
    });

    const pageText = document.body ? document.body.innerText.slice(0, 4000) : '';
    const title    = document.title || location.href;

    sendResponse({ links, pageText, title, url: location.href });
  }
  return true; // keep channel open for async
});
