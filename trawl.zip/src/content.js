// content.js — injected on demand via scripting API

// Guard against double-injection
if (!window.__edgeExplorerInjected) {
  window.__edgeExplorerInjected = true;

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type !== 'EXTRACT_LINKS') return false;

    const base = new URL(location.href);
    const links = [];
    const seen = new Set();

    document.querySelectorAll('a[href]').forEach(a => {
      try {
        const url = new URL(a.getAttribute('href'), base);
        const norm = url.origin + url.pathname.replace(/\/$/, '') + url.search;
        if (seen.has(norm)) return;
        seen.add(norm);
        links.push({
          href: url.href,
          norm,
          anchor: (a.textContent || a.getAttribute('aria-label') || '').trim().slice(0, 120),
          sameDomain: url.hostname === base.hostname
        });
      } catch (_e) {}
    });

    const pageText = document.body ? document.body.innerText.slice(0, 4000) : '';
    const title    = document.title || location.href;

    sendResponse({ links, pageText, title, url: location.href });
    return false; // synchronous response
  });
}
